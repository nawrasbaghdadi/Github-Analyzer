class Services {
    static getToken(){
    let code = (window.location.href.match(/\?code=(.*)/)) ? window.location.href.match(/\?code=(.*)/)[1] : null ;
   if(code){
    let acc_token =  fetch('http://localhost:9999/authenticate/'+code)
     .then(function(response) {
     return response.json();
   })
   .then(function(myJson) {
 
     return myJson.token;
   }).catch(error=> console.log('error:',error));
   return acc_token;
}
}
    static getUserInfo(acc_token){
       let userInfo =  fetch('https://api.github.com/user',{
         headers: new Headers({
             'Content-Type': 'application/json',
             'Authorization': 'token '+acc_token
         })
     })
         .then(res => res.json())
         .then(res => {return res})
         .catch(error => console.log('error',error));
      return userInfo;   
    }
    static getRepositoryInfo(userName , repoName , acc_token){
        const base = `https://api.github.com/repos/${userName}/${repoName}`;
        const urls = [base,`${base}/pulls`,`${base}/contributors`,`${base}/contents/README`];
        const getData = url => fetch(url,{
            headers: new Headers({
                'Content-Type': 'application/json',
                'Accept' : 'application/vnd.github.VERSION.raw',
                'Authorization': `token ${acc_token}`
            })
        })
        .then(res =>{ 
                if(res.status === 404){
                    throw new Error('Repository Not found');
                }
                if(url.includes('README')) { return res.text() }else{ return res.json()};
        })
        .then(res =>res)
        .catch(error=>error);
   
   let allData = Promise
       .all(urls.map(getData))
       .then((alldata) => alldata);
return allData;
    }
   
    static getRepositoryReadMe(repoUrl , acc_token){
        let repositoryreadMe =  fetch(`${repoUrl}/contents/README`,{
            headers: new Headers({
                'Accept' : 'application/vnd.github.VERSION.raw',
                'Authorization': `token ${acc_token}`
            })
        })
            .then(res => res.text())
            .catch(error => console.log('error',error));
         return repositoryreadMe;
    }

}

export default Services;