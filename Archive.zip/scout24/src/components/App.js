import React, { Component } from 'react';
import  UserProfile  from './UserProfile';
import GithubLogin from './GithubLogin';
import AnalyzeForm from './AnalyzeForm';
import RepositoriesTable from './RepositoriesTable';
import Services from '../services'
import '../style/App.css';

class App extends Component {
  constructor(props){
    super(props)
    this.state= {
      userData: null,
      SearchResult : [],
      SystemMsg : ''
    }
    this.acc_token = JSON.parse(localStorage.getItem("acc_token")) || null;
    this.SearchTable =  [];
    this.RepositoryInfo= this.RepositoryInfo.bind(this);
  }

   async componentDidMount(){
     if(!this.acc_token ){
      const  acc_token = await Services.getToken();
      if(acc_token !== undefined){
        localStorage.setItem('acc_token', JSON.stringify(acc_token));
        this.acc_token =  JSON.parse(localStorage.getItem("acc_token"));
      }
     }
    if(this.acc_token){ this.userInfo();}
  }
  async userInfo(){
      const userData =  await Services.getUserInfo(this.acc_token);
      if(!userData.message){this.setState({userData }) }
   }
   RepositoryInfo(data){
    let SearchHistory = JSON.parse(localStorage.getItem('search_history')) || [];
     if(!data[0].hasOwnProperty('message')){
      SearchHistory.push(data);
      this.setState({SearchResult: JSON.stringify(data)})
     localStorage.setItem('search_history', JSON.stringify(SearchHistory));
     }else{
      this.setState({SystemMsg:data[0].message});
     }  
   }
  render() {
    let user,container;
    if(!this.state.userData){
          user = '';
          container = <GithubLogin /> ;
    }else{
        user = <UserProfile userData={this.state.userData}  />;
        container = <AnalyzeForm  service ={Services.getRepositoryInfo} acc_token = {this.acc_token} onSubmit={this.RepositoryInfo}/>;
    }
    const history =  JSON.parse(localStorage.getItem('search_history')) ;
    return (
      <div className="App">
          <header>
            <p> Github Analyzer </p>
            <em>Analyze  Github public repositories</em>
            {user}
          </header>
          {container}
          {this.state.SearchResult.length >0 &&
            <RepositoriesTable data={JSON.parse(this.state.SearchResult)} service ={Services.getRepositoryReadMe} acc_token = {this.acc_token} ResultMod  />
          }
          {history && 
            <RepositoriesTable data={history} service ={Services.getRepositoryReadMe} acc_token = {this.acc_token}   />
          }
      </div>
    );
  }
}

export default App;
