import React,{ Component } from 'react';
import   '../style/RepositoriesTable.css';
import ReadmeComponent from './ReadmeComponent';

class RepositoriesTable extends Component{ 
  constructor(props){
    super(props);
    this.state={
      showReadMe:false
    }
    this.readmeData = null
    this.handelReadme = this.handelReadme.bind(this);
    this.handelStateChangeFromChild = this.handelStateChangeFromChild.bind(this);
  }
  async handelReadme(e){
    e.preventDefault();
    const response = await this.props.service(e.target.dataset.url , this.props.acc_token); 
    this.readmeData=   response;
    this.setState({showReadMe:true},()=>{
      document.body.classList.add('open-modal');
    })
  }
  handelStateChangeFromChild(showHide){
    this.setState({showReadMe:showHide});
  }
  render(){
    const tbody = []; 
    if(this.props.ResultMod){
        tbody.push(
          <tr key={this.props.data[0].id}>
            <td><a href={this.props.data[0].html_url} target="_blank">Repository Link</a></td>
            <td>{(this.props.data[2].length>0) ? this.props.data[2][0]['contributions'] : 0}</td>
            <td>{(this.props.data[1].length>0)? this.props.data[1].length : 0 }</td>
            <td>{(this.props.data[3].length>0) ? <a href="#"  data-url={this.props.data[3].url} onClick={this.handelReadme} >ReadMe</a> : 'No ReadMe found'}</td>
        </tr>);
    }else{
    for(let key in this.props.data){
      tbody.push(
        <tr key={this.props.data[key][0].id}>
          <td><a href={this.props.data[key][0].html_url} target="_blank">Repository Link</a></td>
          <td>{(this.props.data[key][2].length>0) ? this.props.data[key][2][0]['contributions'] : 0}</td>
          <td>{(this.props.data[key][1].length>0)? this.props.data[key][1].length : 0 }</td>
          <td>{(this.props.data[key][3].length>0) ? <a href="#"  data-url={this.props.data[key][0].url} onClick={this.handelReadme} >ReadMe</a> : 'No ReadMe found'} </td>
      </tr>);
    }
  }
    return (
    <div className="container">
      <div className="card">
          <div className="header">
            { (!this.props.ResultMod) ?<h3> <strong>Analyze</strong> Table<small>all searched Repositories starting from react search</small></h3>
                : <h3> <strong>Analyze</strong> Result</h3>
            }          
            </div>
          <table>
              <thead>
                <tr>
                  <th>URL</th>
                  <th>Number OF Commits</th>
                  <th>number pull requests</th>
                  <th>ReadMe</th>
                </tr>
              </thead>
              <tbody >
                  {tbody}
              </tbody>
            </table>
        </div>
       <ReadmeComponent showReadMe = {this.state.showReadMe}  data= {this.readmeData} onShowChanges = {this.handelStateChangeFromChild}/>
         
      </div>    
        )
    }
  }    
 
export default RepositoriesTable;

