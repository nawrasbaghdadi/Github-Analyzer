import React from 'react';
import   '../style/AnalyzeForm.css';


const AnalyzeForm =  (props) =>{ 
    let OwnerInput = null;
    let setOwnerInputRef = element => {
        OwnerInput = element;
    }
    let RepositoryInput = null;
    let setRepositoryInputRef = element => {
        RepositoryInput = element;
    }
    let  handleSubmit= async (e)=>{
        e.preventDefault();
        const response = await props.service(OwnerInput.value , RepositoryInput.value , props.acc_token); 
        OwnerInput.value = '';
        RepositoryInput.value = '';
        props.onSubmit(response);     
    }
    return (
    <div className="container">
    <div className="card search">
        <div className="header">
            <h3> <strong>Analyze</strong> Form
                <small>Please enter a Repository and owner to analyses</small>
            </h3>
                
        </div>
        
            <div className="form">
              <form onSubmit={handleSubmit}>
                <input type="text" placeholder="Owner" ref={setOwnerInputRef}  required/>
                <input type="text" placeholder="Repository" ref={setRepositoryInputRef}  required />
                <button>Analyze now...</button>
              </form>
            </div>
          </div>
</div>
        )
    }
    

 
export default AnalyzeForm;

