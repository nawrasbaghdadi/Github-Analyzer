import React from 'react';
import   '../style/GithubLogin.css';


const GithubLogin =  () =>{  return (
            <div className="container">
                <p> A web application that analyses GitHub repositories , Please login with your github</p>
                <a id="github" href="https://github.com/login/oauth/authorize?client_id=c1e92e7deb88faf833bb" className="signin"> Github login</a>
            </div> 
        )
    }
    

 
export default GithubLogin;