import React from 'react';
import '../style/UserProfile.css';


 const UserProfile =  (props)=> {
      return (
        <div className="user-profile">
            <img src={props.userData.avatar_url} alt="" /><p>Welcome {props.userData.login}</p>
        </div>
      );
   
  }
  
  export default UserProfile;