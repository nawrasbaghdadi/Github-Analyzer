import React from 'react';
import '../style/ReadmeComponent.css'

const  ReadmeComponent=(props)=> {
      let Modal = null;
      let setModalRef = element => {
          Modal = element;
        }
        let hideReadme = ()=>{
            Modal.classList.remove('show');
            document.body.classList.remove('open-modal');
            props.onShowChanges(false);
        }
        return (
            <div className= {`modal ${(!props.showReadMe)? 'hide' : 'show'}`} ref={setModalRef} onClick={hideReadme}>
                <div className="content">
                    <button >X</button>
                    <h2>README</h2>
                    <p> {props.data}</p>
                </div>
            </div>
        )
}

export default ReadmeComponent;