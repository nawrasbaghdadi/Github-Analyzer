### HOW I approach this project
1- Read about the Github API
2- sketch some UI https://sketchboard.me/VBmx66YSItQN#/
3- crated the HTML and CSS
4- Choose the Server , i used https://github.com/prose/gatekeeper ,
5- Start on the React / Frontend Side


### HOW To run the Project
1- Extract the Zip File
2- Cd to-the-extracted-folder
3- run Server
    1- cd server
    2- node index.js
4- cd ..
5- cd scout24
6- npm start //localhost:3000

### Assumptions i made
Both the repository name and owner are required
desktop only

### Known constraints or limitations of your solution.
does not omit duplicates : if user searched for this repository before 
no loading effects 
naming conventions



